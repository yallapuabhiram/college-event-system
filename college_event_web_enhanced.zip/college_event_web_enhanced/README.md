# College Event Management System (Enhanced)

Features added:
- Admin login (session-based)
- Add / Edit / Delete events
- Event capacity (seat limit) and seat availability shown on event details
- Student registration with capacity enforcement
- Event search on public listing
- Export registrations to CSV per event (admin)
- Simulated notifications
- Uses Flask + SQLite. Simple to run locally.

## Quick run steps (Windows)

1. Unzip the project folder.
2. Open Command Prompt in the project folder.
3. Create virtual environment:
   ```bash
   python -m venv venv
   venv\\Scripts\\activate
   ```
4. Install requirements:
   ```bash
   pip install flask werkzeug
   ```
5. Run the app:
   ```bash
   python app.py
   ```
6. Open in browser:
   - Public events: http://127.0.0.1:5000/events
   - Admin login: http://127.0.0.1:5000/login (default admin/admin123)

## Notes
- To change admin password generate a hash:
  ```python
  from werkzeug.security import generate_password_hash
  print(generate_password_hash('your_new_password'))
  ```
  then replace ADMIN_PASSWORD_HASH in `app.py`.
- The `venv` folder is not included in the zip. Create it locally.
- For production hosting use Gunicorn + a real DB (Postgres) and secure secret keys.
