import os
import sqlite3
from datetime import datetime
from functools import wraps
from flask import (
    Flask, render_template, request, redirect, url_for, flash, g, session, send_file, Response
)
from werkzeug.security import generate_password_hash, check_password_hash
import csv
import io

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "college_events.db")

app = Flask(__name__)
app.secret_key = "replace_this_with_a_secure_key"  # change in production

# ====== Simple Admin Credentials ======
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD_HASH = generate_password_hash("admin123")
# =====================================

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

def init_db():
    con = sqlite3.connect(DATABASE)
    cur = con.cursor()
    # events has capacity column now
    cur.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            venue TEXT NOT NULL,
            description TEXT,
            organizer TEXT,
            capacity INTEGER DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER,
            student_name TEXT NOT NULL,
            student_email TEXT NOT NULL,
            student_phone TEXT,
            registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (event_id) REFERENCES events (id)
        )
    """)
    con.commit()
    con.close()

if not os.path.exists(DATABASE):
    init_db()

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username == ADMIN_USERNAME and check_password_hash(ADMIN_PASSWORD_HASH, password):
            session["admin_logged_in"] = True
            flash("Logged in as admin.", "success")
            return redirect(request.args.get("next") or url_for("admin"))
        flash("Invalid credentials.", "danger")
        return redirect(url_for("login"))
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("view_events"))

@app.route("/")
def index():
    return redirect(url_for("view_events"))

@app.route("/events")
def view_events():
    q = request.args.get("q", "").strip().lower()
    db = get_db()
    if q:
        cur = db.execute("SELECT id, name, date, time, venue, organizer FROM events WHERE lower(name) LIKE ? OR lower(venue) LIKE ? ORDER BY date, time", (f"%{q}%", f"%{q}%"))
    else:
        cur = db.execute("SELECT id, name, date, time, venue, organizer FROM events ORDER BY date, time")
    events = cur.fetchall()
    return render_template("view_events.html", events=events, q=q)

@app.route("/event/<int:event_id>")
def event_details(event_id):
    db = get_db()
    ev = db.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
    regs = db.execute("SELECT student_name, student_email, student_phone, registration_date FROM registrations WHERE event_id = ? ORDER BY registration_date DESC", (event_id,)).fetchall()
    if not ev:
        flash("Event not found.", "warning")
        return redirect(url_for("view_events"))
    # calculate seats left (None => unlimited)
    capacity = ev["capacity"]
    seats_left = None
    if capacity is not None:
        registered = db.execute("SELECT COUNT(*) FROM registrations WHERE event_id = ?", (event_id,)).fetchone()[0]
        seats_left = max(0, capacity - registered)
    return render_template("event_details.html", event=ev, regs=regs, seats_left=seats_left)

@app.route("/register/<int:event_id>", methods=["GET", "POST"])
def register(event_id):
    db = get_db()
    ev = db.execute("SELECT id, name, date, time, venue, capacity FROM events WHERE id = ?", (event_id,)).fetchone()
    if not ev:
        flash("Event not found.", "warning")
        return redirect(url_for("view_events"))

    # check capacity
    if ev["capacity"] is not None:
        registered = db.execute("SELECT COUNT(*) FROM registrations WHERE event_id = ?", (event_id,)).fetchone()[0]
        if registered >= ev["capacity"]:
            flash("Sorry, this event is full.", "danger")
            return redirect(url_for("event_details", event_id=event_id))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        phone = request.form.get("phone", "").strip()
        if not name or not email:
            flash("Please enter name and email.", "warning")
            return redirect(url_for("register", event_id=event_id))
        db.execute("INSERT INTO registrations (event_id, student_name, student_email, student_phone) VALUES (?, ?, ?, ?)", (event_id, name, email, phone))
        db.commit()
        flash("Registered successfully!", "success")
        return redirect(url_for("event_details", event_id=event_id))

    return render_template("register.html", event=ev)

@app.route("/admin", methods=["GET", "POST"])
@login_required
def admin():
    db = get_db()
    if request.method == "POST":
        # either add new or update existing if id provided
        event_id = request.form.get("event_id")
        name = request.form.get("name", "").strip()
        date_str = request.form.get("date", "").strip()
        time_str = request.form.get("time", "").strip()
        venue = request.form.get("venue", "").strip()
        organizer = request.form.get("organizer", "").strip()
        description = request.form.get("description", "").strip()
        capacity = request.form.get("capacity", "").strip()
        capacity_val = int(capacity) if capacity.isdigit() else None

        if not (name and date_str and time_str and venue):
            flash("Name, date, time and venue are required.", "warning")
            return redirect(url_for("admin"))
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
            datetime.strptime(time_str, "%H:%M")
        except ValueError:
            flash("Date must be YYYY-MM-DD and time must be HH:MM (24hr).", "danger")
            return redirect(url_for("admin"))

        if event_id:
            db.execute("UPDATE events SET name=?, date=?, time=?, venue=?, description=?, organizer=?, capacity=? WHERE id=?", (name, date_str, time_str, venue, description, organizer, capacity_val, event_id))
        else:
            db.execute("INSERT INTO events (name, date, time, venue, description, organizer, capacity) VALUES (?, ?, ?, ?, ?, ?, ?)", (name, date_str, time_str, venue, description, organizer, capacity_val))
        db.commit()
        flash("Event saved.", "success")
        return redirect(url_for("admin"))

    events = db.execute("SELECT id, name, date, time, venue, organizer, capacity FROM events ORDER BY date DESC").fetchall()
    return render_template("admin.html", events=events)

@app.route("/admin/edit/<int:event_id>")
@login_required
def admin_edit(event_id):
    db = get_db()
    ev = db.execute("SELECT id, name, date, time, venue, description, organizer, capacity FROM events WHERE id = ?", (event_id,)).fetchone()
    if not ev:
        flash("Event not found.", "warning")
        return redirect(url_for("admin"))
    events = db.execute("SELECT id, name, date, time, venue, organizer, capacity FROM events ORDER BY date DESC").fetchall()
    return render_template("admin.html", events=events, edit_event=ev)

@app.route("/admin/delete/<int:event_id>", methods=["POST"])
@login_required
def admin_delete(event_id):
    db = get_db()
    db.execute("DELETE FROM registrations WHERE event_id = ?", (event_id,))
    db.execute("DELETE FROM events WHERE id = ?", (event_id,))
    db.commit()
    flash("Event and its registrations deleted.", "info")
    return redirect(url_for("admin"))

@app.route("/admin/notify/<int:event_id>", methods=["POST"])
@login_required
def admin_notify(event_id):
    db = get_db()
    regs = db.execute("SELECT student_name, student_email FROM registrations WHERE event_id = ?", (event_id,)).fetchall()
    count = len(regs)
    flash(("No registrants to notify." if count == 0 else f"Simulated notifications to {count} registrant(s)."), "success" if count else "info")
    return redirect(url_for("admin"))

@app.route("/admin/export_csv/<int:event_id>")
@login_required
def admin_export_csv(event_id):
    db = get_db()
    ev = db.execute("SELECT name FROM events WHERE id = ?", (event_id,)).fetchone()
    rows = db.execute("SELECT student_name, student_email, student_phone, registration_date FROM registrations WHERE event_id = ? ORDER BY registration_date DESC", (event_id,)).fetchall()
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(["Name", "Email", "Phone", "Registered At"])
    for r in rows:
        cw.writerow([r["student_name"], r["student_email"], r["student_phone"], r["registration_date"]])
    output = si.getvalue().encode("utf-8")
    filename = f"registrations_event_{event_id}.csv"
    return Response(output, mimetype="text/csv", headers={"Content-Disposition": f"attachment;filename={filename}"})

if __name__ == "__main__":
    app.run(debug=True)
